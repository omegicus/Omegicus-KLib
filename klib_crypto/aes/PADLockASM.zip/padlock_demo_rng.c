/*
 * Copyright 1998-2004 VIA Technologies, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * VIA, AND/OR ITS SUPPLIERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "padlock.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

#define MIN_SIZE 64
#define MAX_SIZE 4096*16

static void 
print_star()
{
    int i;

    printf("\n");
    for(i = 0;i < 50; i++)
    {
        printf("*");
    }
    printf("\n");

}

static void 
dump_rand(void *buffer, int len)
{
    int i;
    int *buf = (int *)buffer;
    for(i = 0;i < (int)(len/(sizeof(int))); i++){
        if((i+1)%8)
            printf("0x%08x,",buf[i]);
        else
		{
			printf("0x%08x,\n",buf[i]);
 //           printf("\n");
		}
    }
    printf("\n");
}

void rng_test()
{
    int rng_available;
    unsigned char random_num1[1024] = {0,};
    unsigned char random_num2[1024] = {0,};


    print_star();
    printf("Begin to test Padlock SDK RNG API functions:\n");
    print_star();


    // Padlock SDK RNG API
    rng_available = padlock_rng_available();
    if(rng_available)
    {
        printf("VIA RNG hardware is available!\n");
    }
    else
    {
        printf("VIA RNG hardware isn't available!\n");
        return ;
    }
        
    print_star();
    padlock_rng_rand( random_num1, 1024);
    printf("VIA RNG generates random number 1 :\n");
    dump_rand(random_num1, 1024);    
    print_star();

    print_star();
    padlock_rng_rand( random_num2, 1024);
    printf("VIA RNG generates random number 2 :\n");
    dump_rand(random_num2, 1024);    
    print_star();

    //if((strcmp(random_num1, random_num2)))
	if((memcmp(random_num1, random_num2, 1024)))
    {
        printf("\nVIA RNG random number generation function test ok!\n");
    }
    else
    {
        printf("\nVIA RNG random number generation function test failed!\n");
    }
    
    print_star();

}
