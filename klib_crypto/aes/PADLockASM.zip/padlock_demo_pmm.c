#include "global.h"
#include "rsaref.h"
#include "nn.h"

#include "r_random.h"
#include "rsa.h"
#include <time.h>
#include "padlock.h"
#include <stdio.h>

#ifdef _WIN32_WCE
#include <Winbase.h>
typedef long  clock_t;
#else
#include "padlock_montmul.h"
#endif

#ifdef Linux
#define clock GetMicroSec
#else
#define clock GetTickCount
#endif
#define CLOCKS_PER_SEC 1000 

#define MIN_LENGTH      8	
#define MAX_LENGTH      256
#define CLOCKS_PER_MSEC (CLOCKS_PER_SEC / 1000)
#ifdef Linux
	#ifndef uint_64
		typedef unsigned long long uint_64;
	#endif
#else
	#include <windows.h>
	#ifndef uint_64
		typedef UINT64 uint_64;
	#endif
#endif

#ifdef _X64
#define ALIGN16(x) (unsigned char *)((((uint_64)x) + 15 )&0xfffffffffffffff0)
#else
#define ALIGN16(x) (unsigned char *)((((unsigned int)x) + 15 )&0xfffffff0)
#endif	

int pmm_test_speed()
{
	int i,j,k;
	int DUMMY = 0;
	int TEMP = 0;
	long start,end,elapsed;
	uInt_32 varD[256] = {0};
	int LENGTH;	
	NN_DIGIT* tmp, *tmpbuf;
	NN_DIGIT* a, *abuf;
	NN_DIGIT* b, *bbuf;
	NN_DIGIT* t, *tbuf;
	NN_DIGIT* m, *mbuf; 
	NN_DIGIT* rm, *rmbuf; 
	NN_DIGIT* t1, *t1buf;

//	if ( !padlock_pmm_available())
//	{
//		printf ("montgomery is not available!\n");
//		return 0;
//	}

	printf("*********** begin speed test: ***********\n");
	tmpbuf = (NN_DIGIT*)malloc(65536 );
	abuf = (NN_DIGIT*)malloc(65536 );
	bbuf = (NN_DIGIT*)malloc(65536 );
	tbuf = (NN_DIGIT*)malloc(65536 );
	mbuf = (NN_DIGIT*)malloc(65536 );
	rmbuf = (NN_DIGIT*)malloc(65536 );
	t1buf = (NN_DIGIT*)malloc(65536 );

	if(NULL == tmpbuf || NULL == abuf || NULL == bbuf || NULL == tbuf 
		|| NULL == mbuf || NULL == rmbuf || NULL ==t1buf )
	{
		free(tmpbuf);
		free(abuf);	
		free(bbuf);
		free(tbuf);
		free(mbuf);	
		free(rmbuf);
		free(t1buf);
		printf ("memory allocate error !\n");
		return 0;
	}

	memset(tmpbuf, 0, 65536 );
	memset(mbuf, 0, 65536 );
	memset(abuf, 0, 65536 );
	memset(bbuf, 0, 65536 );
	memset(tbuf, 0, 65536 );
	memset(rmbuf, 0, 65536 );

	
	tmp = (NN_DIGIT*)ALIGN16(tmpbuf);	
	m = (NN_DIGIT*)ALIGN16(mbuf);
	a = (NN_DIGIT*)ALIGN16(abuf);
	b = (NN_DIGIT*)ALIGN16(bbuf);
	t = (NN_DIGIT*)ALIGN16(tbuf);
	rm = (NN_DIGIT*)ALIGN16(rmbuf);
	t1 = (NN_DIGIT*)ALIGN16(t1buf);

	printf ("********** NN_ModMult test: ***********\n");

	
	for (LENGTH = MIN_LENGTH; LENGTH < MAX_LENGTH + 1; LENGTH += 4 )
	{	
		printf ("***************************************\n");
		memset(tmpbuf, 0, 65536 );
		memset(mbuf, 0, 65536 );
		memset(abuf, 0, 65536 );
		memset(bbuf, 0, 65536 );
		memset(tbuf, 0, 65536 );
		memset(rmbuf, 0, 65536 );

		padlock_rng_rand((unsigned char*)(a), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(b), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(m), LENGTH * 4);


		if (NN_Cmp(a, m, LENGTH) > 0)
		{
			void * p  = a;
			a = m;
			m = p;
		}	
		if (NN_Cmp(b, m, LENGTH) > 0)
		{
			void * p  = b;
			b = m;
			m = p;
		}	

		if (NN_EVEN(m, LENGTH))
		{
			printf("EVEN! continue!\n");
			LENGTH-=4;	//for full test
			continue;
		}
		
		start = clock();
		for (k = 0; k < 100; k ++)
		{
			NN_ModMult_hardware( t, a, b, m, LENGTH);
		}
		end = clock();
		elapsed = (end - start) / CLOCKS_PER_MSEC;
		printf ("100 times of NN_ModMult with length %5d need %d milleseconds.\n",LENGTH*32, elapsed);
		start = clock();
		for (k = 0; k < 100; k ++)
		{		
			NN_ModMult_software(varD, a, b, m, LENGTH);
		}
		end = clock();	
		elapsed = (end - start) / CLOCKS_PER_MSEC;
		printf ("100 times of NN_ModMult_software with length %5d need %d milleseconds.\n",LENGTH*32, elapsed);
		
		NN_ModMult_software(varD, a, b, m, LENGTH);
		printf("LENGTH = %5d bits.  ", LENGTH*32);
		
		for (i=0, j=0; i<LENGTH; i++)
			j |= t[i] ^ varD[i]; 

		if (j)
			printf("ERROR: Results differ\n");
		else
			printf("RSA library and PadLock MontMul results identical\n");

	}

	printf ("********** NN_ModExp test: ***********\n");
	for (LENGTH = MIN_LENGTH; LENGTH < MAX_LENGTH + 1; LENGTH += 4 )
	{		
		memset(tmpbuf, 0, 65536 );
		memset(mbuf, 0, 65536 );
		memset(abuf, 0, 65536 );
		memset(bbuf, 0, 65536 );
		memset(tbuf, 0, 65536 );
		memset(rmbuf, 0, 65536 );

		padlock_rng_rand((unsigned char*)(a), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(b), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(m), LENGTH * 4);


		if (NN_Cmp(a, m, LENGTH) > 0)
		{
			void * p  = a;
			a = m;
			m = p;
		}	
		if (NN_Cmp(b, m, LENGTH) > 0)
		{
			void * p  = b;
			b = m;
			m = p;
		}	

		if (NN_EVEN(m, LENGTH))
		{
			printf("EVEN! continue!\n");
			LENGTH-=4;//for full test
			continue;
		}
		
		printf ("***************************************\n");
		start = clock();
		//NN_ModExp( t, a, b, LENGTH, m, LENGTH);
		NN_ModExp_hardware( a, LENGTH, b, LENGTH, t, m);
		end = clock();
		elapsed = (end - start) / CLOCKS_PER_MSEC;
		printf ("once of NN_ModExp with length %5d need %d milleseconds.\n",LENGTH*32, elapsed);
		start = clock();
		NN_ModExp_software(varD, a, b, LENGTH, m, LENGTH);
		end = clock();
		elapsed = (end - start) / CLOCKS_PER_MSEC;
		printf ("once of NN_ModExp_software with length %5d need %d milleseconds.\n",LENGTH*32, elapsed);
		
		printf("LENGTH = %5d bits.  ", LENGTH*32);

		for (i=0, j=0; i<LENGTH; i++)
			j |= t[i] ^ varD[i]; 

		if (j)
			printf("ERROR: Results differ\n");
		else
			printf("RSA library and PadLock ModExp results identical\n");

	}
	
	if (tmpbuf)
	{
		free (tmpbuf);
	}
	if (abuf)
	{
		free (abuf);
	}
	if (bbuf)
	{
		free (bbuf);
	}
	if (mbuf)
	{
		free (mbuf);
	}
	if (rmbuf)
	{
		free (rmbuf);
	}
	if (t1buf)
	{
		free (t1buf);
	}
	if (tbuf)
	{
		free (tbuf);
	}

	return 1;
}

int pmm_test_montmul_modexp()
{
	int i,j;
	int DUMMY = 0;
	int TEMP = 0;
	uInt_32 varD[256] = {0};
	int LENGTH;	
	NN_DIGIT* tmp, *tmpbuf;
	NN_DIGIT* a, *abuf;
	NN_DIGIT* b, *bbuf;
	NN_DIGIT* t, *tbuf;
	NN_DIGIT* m, *mbuf; 
	NN_DIGIT* rm, *rmbuf; 
	NN_DIGIT* t1, *t1buf;

	if ( !padlock_pmm_available())
	{
		printf ("montgomery is not available!Software instead. \n");
//		return 0;
	}
	tmpbuf = (NN_DIGIT*)malloc(65536 );
	abuf = (NN_DIGIT*)malloc(65536 );
	bbuf = (NN_DIGIT*)malloc(65536 );
	tbuf = (NN_DIGIT*)malloc(65536 );
	mbuf = (NN_DIGIT*)malloc(65536 );
	rmbuf = (NN_DIGIT*)malloc(65536 );
	t1buf = (NN_DIGIT*)malloc(65536 );

	if(NULL == tmpbuf || NULL == abuf || NULL == bbuf || NULL == tbuf 
		|| NULL == mbuf || NULL == rmbuf || NULL ==t1buf )
	{
		free(tmpbuf);
		free(abuf);	
		free(bbuf);
		free(tbuf);
		free(mbuf);	
		free(rmbuf);
		free(t1buf);
		printf ("memory allocate error !\n");
		return 0;
	}

	memset(tmpbuf, 0, 65536 );
	memset(mbuf, 0, 65536 );
	memset(abuf, 0, 65536 );
	memset(bbuf, 0, 65536 );
	memset(tbuf, 0, 65536 );
	memset(rmbuf, 0, 65536 );

	
	tmp = (NN_DIGIT*)ALIGN16(tmpbuf);	
	m = (NN_DIGIT*)ALIGN16(mbuf);
	a = (NN_DIGIT*)ALIGN16(abuf);
	b = (NN_DIGIT*)ALIGN16(bbuf);
	t = (NN_DIGIT*)ALIGN16(tbuf);
	rm = (NN_DIGIT*)ALIGN16(rmbuf);
	t1 = (NN_DIGIT*)ALIGN16(t1buf);

	printf ("********** NN_ModMult test: ***********\n");

	for (LENGTH = MIN_LENGTH; LENGTH < MAX_LENGTH + 1; LENGTH += 4 )
	{		
		memset(tmpbuf, 0, 65536 );
		memset(mbuf, 0, 65536 );
		memset(abuf, 0, 65536 );
		memset(bbuf, 0, 65536 );
		memset(tbuf, 0, 65536 );
		memset(rmbuf, 0, 65536 );

		padlock_rng_rand((unsigned char*)(a), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(b), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(m), LENGTH * 4);

		if (NN_Cmp(a, m, LENGTH) > 0)
		{
			void * p  = a;
			a = m;
			m = p;
		}	
		if (NN_Cmp(b, m, LENGTH) > 0)
		{
			void * p  = b;
			b = m;
			m = p;
		}	

		if (NN_EVEN(m, LENGTH))
		{
			printf("EVEN! continue!\n");
			LENGTH-=4;//for full test
			continue;
		}
		
		NN_ModMult_hardware( t, a, b, m, LENGTH);

		NN_ModMult_software(varD, a, b, m, LENGTH);
		
		printf("LENGTH = %5d bits.  ", LENGTH*32);

		for (i=0, j=0; i<LENGTH; i++)
			j |= t[i] ^ varD[i]; 

		if (j)
			printf("ERROR: Results differ\n");
		else
			printf("RSA library and PadLock MontMul results identical\n");

	}

	printf ("********** NN_ModExp test: ***********\n");
	for (LENGTH = MIN_LENGTH; LENGTH < MAX_LENGTH + 1; LENGTH += 4 )
	{		
		memset(tmpbuf, 0, 65536 );
		memset(mbuf, 0, 65536 );
		memset(abuf, 0, 65536 );
		memset(bbuf, 0, 65536 );
		memset(tbuf, 0, 65536 );
		memset(rmbuf, 0, 65536 );

		padlock_rng_rand((unsigned char*)(a), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(b), LENGTH * 4);
		padlock_rng_rand((unsigned char*)(m), LENGTH * 4);


		if (NN_Cmp(a, m, LENGTH) > 0)
		{
			void * p  = a;
			a = m;
			m = p;
		}	
		if (NN_Cmp(b, m, LENGTH) > 0)
		{
			void * p  = b;
			b = m;
			m = p;
		}	

		if (NN_EVEN(m, LENGTH))
		{
			printf("EVEN! continue!\n");
			LENGTH-=4;//for full test
			continue;
		}
		
//		NN_ModExp_hardware( t, a, b, LENGTH, m, LENGTH);
		NN_ModExp_hardware( a, LENGTH, b, LENGTH, t, m);//parameter order is update.

		NN_ModExp_software(varD, a, b, LENGTH, m, LENGTH);
		
		printf("LENGTH = %5d bits.  ", LENGTH*32);

		for (i=0, j=0; i<LENGTH; i++)
			j |= t[i] ^ varD[i]; 

		if (j)
			printf("ERROR: Results differ\n");
		else
			printf("RSA library and PadLock ModExp results identical\n");

	}
	
	if (tmpbuf)
	{
		free (tmpbuf);
	}
	if (abuf)
	{
		free (abuf);
	}
	if (bbuf)
	{
		free (bbuf);
	}
	if (mbuf)
	{
		free (mbuf);
	}
	if (rmbuf)
	{
		free (rmbuf);
	}
	if (t1buf)
	{
		free (t1buf);
	}
	if (tbuf)
	{
		free (tbuf);
	}


	return 1;
}



void rsa_test()
{
	R_RANDOM_STRUCT random;
	R_RSA_PROTO_KEY protoKey;
	R_RSA_PUBLIC_KEY pubKey;
	R_RSA_PRIVATE_KEY privKey;
	int keySize = 512;
	char input[2048];
	char output[2048];
	int outLen = 0;
	clock_t start, finish;
	clock_t total = 0;
	double timing = 0.;
	double rate = 0.;
	int i = 0;
	unsigned int ustart, ufinish; 

	char encryptData[2048];
	int encryptLen = 0;

	printf ("************ Begin to test RSA funtions ***************\n");
	memset(input, 0, 1024);

	R_RandomInit(&random);

	// init the seeds
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);
	R_RandomUpdate(&random, "12345678901234567890123456789012", 32);

	for (keySize; keySize <= MAX_RSA_MODULUS_BITS; keySize += 256)
	{
		protoKey.bits = keySize;
		protoKey.useFermat4 = 1;

		printf ("***************************************\n");	
		printf("RSA key size %d bits\n", keySize);
		
		start = clock();
		ustart = (unsigned int)start;

		if(R_GeneratePEMKeys(&pubKey, &privKey, &protoKey, &random))
		{
			printf ("Error creating keys - Error calling GeneratePEMKeys()\n");
		}
		finish = clock();
		ufinish = (unsigned int)finish;
		if (ufinish >= ustart)
		{
			ufinish -= ustart;
		}
		else
		{
			ufinish = (0xffffffff - ustart) + ufinish;
		}

		timing = (double)ufinish / CLOCKS_PER_SEC;

		printf("Generate key \t\t\t\t\ttime: %6.3f seconds\n",  timing);
		
		
		memset(input, 1, 1024);
		memset(output, 0, 1024);
		memset(encryptData, 0, 1024);

		start = clock();
		ustart = (unsigned int)start;
		for (i = 0; i < 10; i++)
		{
			if (RSAPublicEncrypt(encryptData, &encryptLen, input, keySize/8 - 11, &pubKey, &random))
				printf("error RSAPublicEncrypt %d\n", i);
		}

		finish = clock();
		ufinish = (unsigned int)finish;
		if (ufinish >= ustart)
		{
			ufinish -= ustart;
		}
		else
		{
			ufinish = (0xffffffff - ustart) + ufinish;
		}
		timing = (double)ufinish / CLOCKS_PER_SEC;
		printf("Public key encrypt data   %d bytes 10 times,\ttime: %6.3f seconds\n", 
				keySize/8 - 11, timing);

		printf("Private key decrypt data  %d bytes 10 times", encryptLen);
		start = clock();
		ustart = (unsigned int)start;
		for (i = 0; i < 10; i++)
		{
			if (RSAPrivateDecrypt(output, &outLen, encryptData, encryptLen, &privKey))
				printf("error RSAPrivateDecrypt %d\n", i);
		}

		finish = clock();
		ufinish = (unsigned int)finish;
		if (ufinish >= ustart)
		{
			ufinish -= ustart;
		}
		else
		{
			ufinish = (0xffffffff - ustart) + ufinish;
		}
		timing = (double)ufinish / CLOCKS_PER_SEC;
		printf("\ttime: %6.3f seconds\n", timing);

		if (memcmp(output, input, keySize/8 - 11) != 0)
			printf("Decrypt result error!!!!\n");

		
		memset(input, 3, 1024);
		memset(output, 0, 1024);
		memset(encryptData, 0, 1024);

		start = clock();
		ustart = (unsigned int)start;
		for (i = 0; i < 10; i++)
		{
			if (RSAPrivateEncrypt(encryptData, &encryptLen, input, keySize/8 - 11, &privKey))
				printf("error RSAPrivateEncrypt %d\n", i);
		}

		finish = clock();
		ufinish = (unsigned int)finish;
		if (ufinish >= ustart)
		{
			ufinish -= ustart;
		}
		else
		{
			ufinish = (0xffffffff - ustart) + ufinish;
		}
		timing = (double)ufinish / CLOCKS_PER_SEC;
		printf("Private key encrypt data  %d bytes 10 times, \ttime: %6.3f seconds\n", 
				keySize/8 - 11, timing);
		
		
		printf("Public key decrypt data   %d bytes 10 times, ", encryptLen);
		start = clock();
		ustart = (unsigned int)start;
		for (i = 0; i < 10; i++)
		{
  			if (RSAPublicDecrypt(output, &outLen, encryptData, encryptLen, &pubKey))
				printf("error RSAPublicDecrypt %d\n", i);
		}

		finish = clock();
		ufinish = (unsigned int)finish;
		if (ufinish >= ustart)
		{
			ufinish -= ustart;
		}
		else
		{
			ufinish = (0xffffffff - ustart) + ufinish;
		}
		timing = (double)ufinish / CLOCKS_PER_SEC;
		printf("\ttime: %6.3f seconds\n", timing);


		if (memcmp(output, input, keySize/8 - 11) != 0)
			printf("Decrypt result error!!!!\n");

	}
	R_RandomFinal(&random);

	printf ("************ Finish to test RSA funtions ***************\n");
}
