/*
 * Copyright 1998-2004 VIA Technologies, Inc. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sub license,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * VIA, AND/OR ITS SUPPLIERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include "padlock.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>


#define MIN_SIZE 1024 
#define MAX_SIZE 4096*64

int ace_available;
int ace2_available;

///////////////////////////////////////////////////////////////////////////////////
//    AES AES Cryptography Testing Vestors from 
//    NIST Recommendation for Block Cipher Modes of Operation : Methods and Techniques
//    Appendix F: Example Vectors for Modes of Operation of the AES
//    http://csrc.nist.gov/publications/ nistpubs/800-38a/sp800-38a.pdf 
//
//    By  Danial Miao
//    2004-06-18

/***************** ecb mode aes key plaintxt ciphertxt test vector *****************/

unsigned char 
ecb_aes128_key[16] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 
		       0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f };

unsigned char 
ecb_aes192_key[24] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
		       0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
		       0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17 };

unsigned char 
ecb_aes256_key[32] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
			 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
		       0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
		       0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f };

unsigned char 
ecb_aes_plain[64] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
			0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,     
		      0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
		      0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
		      0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
		      0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,	  
		      0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
		      0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff };

unsigned char 
ecb_aes128_cipher[64] = { 0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30,
			  0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a,
			  0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30,
			  0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a,
			  0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30,
			  0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a,
			  0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30,
			  0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a };

unsigned char 
ecb_aes192_cipher[64] = { 0xdd, 0xa9, 0x7c, 0xa4, 0x86, 0x4c, 0xdf, 0xe0,
			  0x6e, 0xaf, 0x70, 0xa0, 0xec, 0x0d, 0x71, 0x91,  
			  0xdd, 0xa9, 0x7c, 0xa4, 0x86, 0x4c, 0xdf, 0xe0,
			  0x6e, 0xaf, 0x70, 0xa0, 0xec, 0x0d, 0x71, 0x91,
			  0xdd, 0xa9, 0x7c, 0xa4, 0x86, 0x4c, 0xdf, 0xe0,
			  0x6e, 0xaf, 0x70, 0xa0, 0xec, 0x0d, 0x71, 0x91,  
			  0xdd, 0xa9, 0x7c, 0xa4, 0x86, 0x4c, 0xdf, 0xe0,
			  0x6e, 0xaf, 0x70, 0xa0, 0xec, 0x0d, 0x71, 0x91 };

unsigned char 
ecb_aes256_cipher[64] = { 0x8e, 0xa2, 0xb7, 0xca, 0x51, 0x67, 0x45, 0xbf,
			  0xea, 0xfc, 0x49, 0x90, 0x4b, 0x49, 0x60, 0x89,  
			  0x8e, 0xa2, 0xb7, 0xca, 0x51, 0x67, 0x45, 0xbf,
			  0xea, 0xfc, 0x49, 0x90, 0x4b, 0x49, 0x60, 0x89,
			  0x8e, 0xa2, 0xb7, 0xca, 0x51, 0x67, 0x45, 0xbf,
			  0xea, 0xfc, 0x49, 0x90, 0x4b, 0x49, 0x60, 0x89,  
			  0x8e, 0xa2, 0xb7, 0xca, 0x51, 0x67, 0x45, 0xbf,
			  0xea, 0xfc, 0x49, 0x90, 0x4b, 0x49, 0x60, 0x89 };

/***************** cbc mode aes key plaintxt ciphertxt test vector *****************/
int cbc_aes128_key[4] = {0x16157e2b, 0xa6d2ae28, 0x8815f7ab, 0x3c4fcf09};

int cbc_aes192_key[6] = {0xf7b0738e, 0x52640eda, 0x2bf310c8, 0xe5799080, 
			 0xd2eaf862, 0x7b6b2c52};

int cbc_aes256_key[8] = {0x10eb3d60, 0xbe71ca15, 0xf0ae732b, 0x81777d85,
			 0x072c351f, 0xd708613b, 0xa310982d, 0xf4df1409};

int cbc_aes_iv[4] = {0x03020100, 0x07060504, 0x0b0a0908, 0x0f0e0d0c};
    
int cbc_aes_plain[16] = {0xe2bec16b, 0x969f402e, 0x117e3de9, 0x2a179373, \
			  0x578a2dae, 0x9cac031e, 0xac6fb79e, 0x518eaf45, \
			   0x461cc830, 0x11e45ca3, 0x19c1fbe5, 0xef520a1a, \
			    0x45249ff6, 0x179b4fdf, 0x7b412bad, 0x10376ce6};

int cbc_aes128_cipher[16] = {0xacab4976, 0x46b21981, 0x9b8ee9ce, 0x7d19e912, \
				0x9bcb8650, 0xee197250, 0x3a11db95, 0xb2787691, \
			     0xb8d6be73, 0x3b74c1e3, 0x9ee61671, 0x16952222, \
			     0xa1caf13f, 0x09ac1f68, 0x30ca0e12, 0xa7e18675};

int cbc_aes192_cipher[16] = {0xb21d024f, 0x3d63bc43, 0x3a187871, 0xe871a09f, \
				0xa9add9b4, 0xf4ed7dad, 0x7638e7e5, 0x5a14693f, \
			     0x20241b57, 0xe07afb12, 0xacbaa97f, 0xe002f13d, \
			     0x79e2b008, 0x81885988, 0xe6a920d9, 0xcd15564f};

int cbc_aes256_cipher[16]= {0x044c8cf5, 0xbaf1e5d6, 0xfbab9e77, 0xd6fb7b5f, \
			       0x964efc9c, 0x8d80db7e, 0x7b779f67, 0x7d2c70c6, \
			    0x6933f239, 0xcfbad9a9, 0x63e230a5, 0x61142304, \
			    0xe205ebb2, 0xfce99bc3, 0x07196cda, 0x1b9d6a8c};

/***************** 128bits data block cfb mode aes key plaintxt ciphertxt test vector *****************/
//	Because VIA ACE hardware can only support 16 bytes data cryptography
//	in Padlock SDK vesion 1.0.0, only 128bits cfb is supported
//	while 1bit cfb and 8bits cfb are not supported by Padlock SDK version 1.0.0

int cfb128_aes128_key[4] = {0x16157e2b, 0xa6d2ae28, 0x8815f7ab, 0x3c4fcf09};

int cfb128_aes192_key[6] = {0xf7b0738e, 0x52640eda, 0x2bf310c8, 0xe5799080,
			    0xd2eaf862, 0x7b6b2c52};

int cfb128_aes256_key[8] = {0x10eb3d60, 0xbe71ca15, 0xf0ae732b, 0x81777d85, 
			    0x072c351f, 0xd708613b, 0xa310982d, 0xf4df1409};

int cfb128_aes_iv[4] = {0x03020100, 0x07060504, 0x0b0a0908, 0x0f0e0d0c};
    
int cfb128_aes_plain[16] = {0xe2bec16b, 0x969f402e, 0x117e3de9, 0x2a179373, \
			       0x578a2dae, 0x9cac031e, 0xac6fb79e, 0x518eaf45, \
			      0x461cc830, 0x11e45ca3, 0x19c1fbe5, 0xef520a1a, \
			       0x45249ff6, 0x179b4fdf, 0x7b412bad, 0x10376ce6};

int cfb128_aes128_cipher[16]= {0x2ed93f3b, 0x20ad2db7, 0xf8493433, 0x4afb3ce8, \
				  0x3745a6c8, 0x3fa9b3a0, 0xadcde3cd, 0x8be51c9f, \
			       0x671f7526, 0x40b1cba3, 0xf18c80b1, 0xdff4a487, \
			       0x35054bc0, 0x0e1c5d7c, 0x6fc6c4ea, 0xe6f2f79f};

int cfb128_aes192_cipher[16]= {0x6f0dc8cd, 0xab8cf1dd, 0x0959c234, 0x74419ac9, \
				  0x7f7fce67, 0x21361781, 0x702b1a96, 0x7a3d1d17, \
			       0x1d8a1e2e, 0xb1889bd5, 0xed0fe6c8, 0xc9c4fa1e, \
			       0x9c9f5fc0, 0xa04f83a9, 0xba8fae42, 0xff094b58};

int cfb128_aes256_cipher[16]= {0xbf847edc, 0x4b1679da, 0x8684cd7e, 0x60385d98, \
				  0x14edff39, 0xc8b1283b, 0x633c1132, 0x7b40e531, \
			       0x241310df, 0x924be515, 0xa8d03ea1, 0xf9e27a26, \
			       0x7485a375, 0xf8ceb91a, 0x3d623120, 0x71e4b155};

/*****************  ofb mode aes key plaintxt ciphertxt test vector *****************/
//	Because VIA ACE hardware can only support 16 bytes data cryptography
//	in Padlock SDK vesion 1.0.0, only 128bits ofb is supported

int ofb_aes128_key[4] = {0x16157e2b, 0xa6d2ae28, 0x8815f7ab, 0x3c4fcf09};

int ofb_aes192_key[6] = {0xf7b0738e, 0x52640eda, 0x2bf310c8, 0xe5799080,
			  0xd2eaf862, 0x7b6b2c52};

int ofb_aes256_key[8] = {0x10eb3d60, 0xbe71ca15, 0xf0ae732b, 0x81777d85, 
			 0x072c351f, 0xd708613b, 0xa310982d, 0xf4df1409};

int ofb_aes_iv[4] = {0x03020100, 0x07060504, 0x0b0a0908, 0x0f0e0d0c};
    
int ofb_aes_plain[16] = {0xe2bec16b, 0x969f402e, 0x117e3de9, 0x2a179373, \
			    0x578a2dae, 0x9cac031e, 0xac6fb79e, 0x518eaf45, \
			   0x461cc830, 0x11e45ca3, 0x19c1fbe5, 0xef520a1a, \
			    0x45249ff6, 0x179b4fdf, 0x7b412bad, 0x10376ce6};

int ofb_aes128_cipher[16]= {0x2ed93f3b, 0x20ad2db7, 0xf8493433, 0x4afb3ce8, \
			       0x8d508977, 0x038f9116, 0xda523cf5, 0x25d84ec5, \
			    0x1e054097, 0xf6ec5f9c, 0xa8f74443, 0xcced6022, \
			    0x28654c30, 0x78c759f6, 0xd910a566, 0x5eaed6c1};

int ofb_aes192_cipher[16]= {0x6f0dc8cd, 0xab8cf1dd, 0x0959c234, 0x74419ac9, \
			       0x8d8bc2fc, 0x7c83634c, 0x0017e809, 0x010410c1, \
			    0xea9a9a8d, 0x6f59f6c0, 0x4d6d9c55, 0xf2a559af, \
			    0x08209f6d, 0x3e6cca57, 0x4b52ac9c, 0x2ac9acd9};

int ofb_aes256_cipher[16]= {0xbf847edc, 0x4b1679da, 0x8684cd7e, 0x60385d98, \
			       0x67dceb4f, 0x3a0bd240, 0xd86a8fc8, 0x8db04f2a, \
			    0xa047ab71, 0xed6ee886, 0x5b1c9df3, 0x08c497ba, \
			    0x1d142601, 0xe87bf367, 0x8b5a8f53, 0x84e440e7};
/********************CRT mode********************************************/
int ctr_aes128_key[4] = {0x16157e2b, 0xa6d2ae28, 0x8815f7ab, 0x3c4fcf09};

int ctr_aes192_key[6] = {0xf7b0738e, 0x52640eda, 0x2bf310c8, 0xe5799080,
			    0xd2eaf862, 0x7b6b2c52};

int ctr_aes256_key[8] = {0x10eb3d60, 0xbe71ca15, 0xf0ae732b, 0x81777d85, 
			    0x072c351f, 0xd708613b, 0xa310982d, 0xf4df1409};

int ctr_aes_iv[4] = {0xf3f2f1f0, 0xf7f6f5f4, 0xfbfaf9f8, 0xfffefdfc};
    
int ctr_aes_plain[16] ={0xe2bec16b, 0x969f402e, 0x117e3de9, 0x2a179373, \
			    0x578a2dae, 0x9cac031e, 0xac6fb79e, 0x518eaf45, \
			   0x461cc830, 0x11e45ca3, 0x19c1fbe5, 0xef520a1a, \
			    0x45249ff6, 0x179b4fdf, 0x7b412bad, 0x10376ce6};

int ctr_aes128_cipher[16]= {0x91614d87,0x26e320b6,0x6468ef1b,0xceb60d99, \
			 0x6bf60698,0xfffd7079,0x7b181786,0xfffdffb9, \
			 0x3edfe45a,0x5ed3d5db,0x02094f5b,0xab3eb00d, \
			 0xda1d031e,0xd103be2f,0xa0702179,0xee9c00f3};

int ctr_aes192_cipher[16]= {0x2493bc1a, 0xa21c5217, 0x59042b4f, 0x0b6e7efe, \
			    0xec390309, 0xeffaa60a, 0xc6c2ccd5, 0x948ecef4, \
			    0x6bb2361e, 0x70c6ebd1, 0x661dbdd1, 0xf7ab2056, \
			    0xf6a7784f, 0x580998d2, 0xecda975a, 0x50b0c658};


int ctr_aes256_cipher[16]= {0x13c31e60, 0xa5895777, 0x04f5a7b7, 0x28d2f3bb, \
			    0xcae343f4, 0x9ab5624d, 0x90e984ca, 0xc5f5caca, \
			    0xda30092b, 0x4ce93da2, 0xba1770e8, 0x8d98842d, \
			    0x8dc5c9df, 0xa6ad7ab6, 0x08ddc213, 0xa6417945};



/************************************************************************/

unsigned char scratch[64] = {0,};



static void 
print_ace_error(AES_RESULT res)
{
    switch (res)
    {
    case AES_ADDRESS_NOT_ALIGNED:    printf("Addresses Not Aligned Error for fast Cryptography!\n");
				    break;
    case AES_NOT_BLOCKED:	     printf("Invalid Data Size Error! Should be n*16 bytes!\n");
				    break;
    case AES_KEY_NOT_SUPPORTED:    printf("Invalid Key Length Error! Should be 16/24/32 bytes!\n");
				    break;
    case AES_MODE_NOT_SUPPORTED:    printf("Invalid Cipher Mode Error! Should be ecb/cbc/cfb/ofb!\n");
				    break;
    default: 
		printf("Hardware CRYPTO Failed!\n");
		break;
    }
}

static void 
print_star()
{
    int i;

    printf("\n");
    for(i = 0;i < 50; i++)
    {
	printf("*");
    }
    printf("\n");

}

// test VIA Padlock SDK ACE plain aes API
static int
test_padlock_aes(ACE_AES_MODE mode, KEY_LENGTH key_len, int nbytes, int in_block)
{
    struct ace_aes_context *ctx = NULL;
    char cipher_mode[10]= {0,};
    char cipher_key[10] = {0,};
    
    unsigned char *p_key = NULL;
    unsigned char *p_plain = NULL;
    unsigned char *p_cipher = NULL;
    unsigned char temp_iv[16]={0,};
    unsigned char orig_iv[16]={0,};
    
    AES_RESULT res;

    switch (mode)
    {
    case ACE_AES_ECB:  memcpy(cipher_mode,"ECB",3);
			    p_plain = (unsigned char *)ecb_aes_plain;
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ecb_aes128_key;
						    p_cipher = (unsigned char *)ecb_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ecb_aes192_key;
						    p_cipher = (unsigned char *)ecb_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ecb_aes256_key;
						    p_cipher = (unsigned char *)ecb_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    case ACE_AES_CBC:  memcpy(cipher_mode,"CBC",3);
			    p_plain = (unsigned char *)cbc_aes_plain;
			    memcpy(orig_iv,(unsigned char *)cbc_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	    memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)cbc_aes128_key;
						    p_cipher = (unsigned char *)cbc_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)cbc_aes192_key;
						    p_cipher = (unsigned char *)cbc_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)cbc_aes256_key;
						    p_cipher = (unsigned char *)cbc_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    case ACE_AES_CFB128:  memcpy(cipher_mode,"CFB128",6);
			    p_plain = (unsigned char *)cfb128_aes_plain;
			    memcpy(orig_iv,(unsigned char *)cfb128_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)cfb128_aes128_key;
						    p_cipher = (unsigned char *)cfb128_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)cfb128_aes192_key;
						    p_cipher = (unsigned char *)cfb128_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)cfb128_aes256_key;
						    p_cipher = (unsigned char *)cfb128_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;


					
    case ACE_AES_OFB128:    memcpy(cipher_mode,"OFB128",6);
			    p_plain = (unsigned char *)ofb_aes_plain;
			    memcpy(orig_iv,(unsigned char *)ofb_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ofb_aes128_key;
						    p_cipher = (unsigned char *)ofb_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ofb_aes192_key;
						    p_cipher = (unsigned char *)ofb_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ofb_aes256_key;
						    p_cipher = (unsigned char *)ofb_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
	
	case ACE_AES_CTR:	{
							memcpy(cipher_mode,"CTR",3);////////////
							p_plain=(unsigned char*)ctr_aes_plain;
							memcpy(orig_iv,(unsigned char*)ctr_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	    memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ctr_aes128_key;
						    p_cipher = (unsigned char *)ctr_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ctr_aes192_key;
						    p_cipher = (unsigned char *)ctr_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ctr_aes256_key;
						    p_cipher = (unsigned char *)ctr_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
							break;
						}
    default :		    printf("Invalid Cipher Mode Error!\n");
			    return -1;
    }
    
    print_star();
    printf("%s mode plain AES %sbits key cipher test:\n",cipher_mode,cipher_key);
    //print_star();

    // create the ace aes cipher context 
    ctx = padlock_aes_begin();
    if(NULL == ctx)
    {
	print_ace_error(AES_FAILED);
	return -1;
    }
    // set cipher key
    res = padlock_aes_setkey( ctx, p_key, key_len);
    if(res != AES_SUCCEEDED)
    {
	print_ace_error(res);
	padlock_aes_close(ctx);
	return -1;
    }
    
    // because the iv will be updated by the plain aes encryption and decryption API
    // here we reserve it in the orig_iv
    memcpy(temp_iv, orig_iv, 16);

    // set cipher mode and iv
    res = padlock_aes_setmodeiv( ctx, mode, temp_iv);
    if(res != AES_SUCCEEDED)
    {
	print_ace_error(res);
		padlock_aes_close(ctx);
	return -1;
    }
    
    if (in_block)    
    {
	// call ACE plain aes encryption API block by block.
	int pos = 0;
		int length = nbytes;
	while (length >= 16){
	    res = padlock_aes_encrypt( ctx, p_plain+pos, scratch+pos, 16);
	    if(res != AES_SUCCEEDED)
	    {
		print_ace_error(res);
				padlock_aes_close(ctx);
		return -1;
	    }
    
	    pos += 16;
	    length -= 16;
	}
    }
    else{
	// call ACE plain aes encryption API
	res = padlock_aes_encrypt( ctx, p_plain, scratch, nbytes);
	if(res != AES_SUCCEEDED)
	{
	    print_ace_error(res);
			padlock_aes_close(ctx);
	    return -1;
	}
    }
    
    // see whether the iv has been updated by ACE plain aes encryption API
	
    // verify the result of encryption
    if (memcmp (scratch, p_cipher, nbytes))
    {
	printf("%s mode plain AES-%s encryption test failed.\n",cipher_mode,cipher_key);
    }
    else
    {
	printf("%s mode plain AES-%s encryption test ok\n",cipher_mode,cipher_key);
    }

    //print_star();
    
    /////////////////////////////////////////////////////////////////////
    
    // because the temp_iv has been updated 
    // we have to restore orig_iv to it here
    memcpy(temp_iv, orig_iv, 16);

    // reset iv for decrytion
    res = padlock_aes_setmodeiv( ctx, mode, temp_iv);
    if(res != AES_SUCCEEDED)
    {
	print_ace_error(res);
		padlock_aes_close(ctx);
	return -1;
    }

    if (in_block)
    {
	// call ACE plain aes decryption API block by block.
	int pos = 0;
		int length = nbytes;
	while (length >= 16){
	    res = padlock_aes_decrypt( ctx, p_cipher+pos, scratch+pos, 16);
	    if(res != AES_SUCCEEDED)
	    {
		print_ace_error(res);
				padlock_aes_close(ctx);
		return -1;
	    }

	    pos += 16;
	    length -= 16;
	}
    }
    else{
	// call ACE plain aes decryption API
	res = padlock_aes_decrypt( ctx, p_cipher, scratch, nbytes);
	if(res != AES_SUCCEEDED)
	{
	    print_ace_error(res);
			padlock_aes_close(ctx);
	    return -1;
	}
    }
     
    // verify the result of decryption
    if (memcmp (scratch, p_plain, nbytes))
    {
	printf("%s mode plain AES-%s decryption test failed.\n",cipher_mode,cipher_key);
    }
    else 
    {
	printf("%s mode plain AES-%s decryption test ok\n",cipher_mode,cipher_key);
    }

    // destroy the ace aes cipher context
    padlock_aes_close( ctx);
    
    //print_star();

    return 0;
}

// test VIA Padlock SDK ACE aligned aes API
static int
test_padlock_aligned_aes(ACE_AES_MODE mode, KEY_LENGTH key_len, int nbytes, int in_block)
{
    struct aligned_memory_context *buf_aligned_mctx = NULL;

    char cipher_mode[10]= {0,};
    char cipher_key[10] = {0,};
    
    unsigned char *p_key = NULL;
    unsigned char *p_plain = NULL;
    unsigned char *p_cipher = NULL;
    unsigned char temp_iv[16]={0,};
    unsigned char orig_iv[16]={0,};
    
    AES_RESULT res;

    switch (mode)
    {
	case ACE_AES_CTR:	{
							memcpy(cipher_mode,"CTR",3);////////////
							p_plain=(unsigned char*)ctr_aes_plain;
							memcpy(orig_iv,(unsigned char*)ctr_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ctr_aes128_key;
						    p_cipher = (unsigned char *)ctr_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ctr_aes192_key;
						    p_cipher = (unsigned char *)ctr_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ctr_aes256_key;
						    p_cipher = (unsigned char *)ctr_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
						}
						break;

    case ACE_AES_ECB:  memcpy(cipher_mode,"ECB",3);
			    p_plain = (unsigned char *)ecb_aes_plain;
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ecb_aes128_key;
						    p_cipher = (unsigned char *)ecb_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ecb_aes192_key;
						    p_cipher = (unsigned char *)ecb_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ecb_aes256_key;
						    p_cipher = (unsigned char *)ecb_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    case ACE_AES_CBC:  memcpy(cipher_mode,"CBC",3);
			    p_plain = (unsigned char *)cbc_aes_plain;
			    memcpy(orig_iv,(unsigned char *)cbc_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)cbc_aes128_key;
						    p_cipher = (unsigned char *)cbc_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)cbc_aes192_key;
						    p_cipher = (unsigned char *)cbc_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)cbc_aes256_key;
						    p_cipher = (unsigned char *)cbc_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    case ACE_AES_CFB128:  memcpy(cipher_mode,"CFB128",6);
			    p_plain = (unsigned char *)cfb128_aes_plain;
			    memcpy(orig_iv,(unsigned char *)cfb128_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)cfb128_aes128_key;
						    p_cipher = (unsigned char *)cfb128_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)cfb128_aes192_key;
						    p_cipher = (unsigned char *)cfb128_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)cfb128_aes256_key;
						    p_cipher = (unsigned char *)cfb128_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    case ACE_AES_OFB128:  memcpy(cipher_mode,"OFB128",6);
			    p_plain = (unsigned char *)ofb_aes_plain;
			    memcpy(orig_iv,(unsigned char *)ofb_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	     memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ofb_aes128_key;
						    p_cipher = (unsigned char *)ofb_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ofb_aes192_key;
						    p_cipher = (unsigned char *)ofb_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ofb_aes256_key;
						    p_cipher = (unsigned char *)ofb_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    default :		     printf("Invalid Cipher Mode Error!\n");
			    return -1;
    }
    
    print_star();
    printf("%s mode aligned AES %sbits key cipher test:\n",cipher_mode,cipher_key);
    //print_star();

    // create address aligned buffer context
    if (in_block)
	buf_aligned_mctx = padlock_aligned_malloc(16);
    else
	buf_aligned_mctx = padlock_aligned_malloc(nbytes);
    
	if( NULL == buf_aligned_mctx)
	{
		print_ace_error(AES_FAILED);
		return -1;
	}
    // because the temp_iv will be updated 
    // we have to reserve it to orig_iv and copy it to temp_iv here
    memcpy(temp_iv, orig_iv, 16);

    if (in_block){
	// operate the data block by block.
	int pos = 0;
		int length = nbytes;
	while (length >= 16){
	    // copy a block data to be encrypted to aligned buffer
	    res = padlock_aligned_memcpy_to(buf_aligned_mctx, p_plain + pos, 16);
	    if(res != AES_SUCCEEDED)
	    {
		printf("aligned memory copy error!\n");
				padlock_aligned_mfree( buf_aligned_mctx);
		return -1;
	    }
	    res = padlock_aes_aligned_encrypt(p_key, key_len, mode, buf_aligned_mctx, temp_iv);
	    if(res != AES_SUCCEEDED)
	    {
		print_ace_error(res);
				padlock_aligned_mfree( buf_aligned_mctx);
		return -1;
	    }
    
	    // copy the encrypted result from aligned buffer to scratch, each time one block.
	    res = padlock_aligned_memcpy_from(buf_aligned_mctx, scratch + pos, 16);
	    if(res != AES_SUCCEEDED)
	    {
		printf("aligned memory copy error!\n");
				padlock_aligned_mfree( buf_aligned_mctx);
		return -1;
	    }
	    length -= 16;
	    pos += 16;
	}
    }
    else{ 
	// operate the data as a whole.

	// copy data to be encrypted to aligned buffer
	res = padlock_aligned_memcpy_to(buf_aligned_mctx, p_plain, nbytes);
	if(res != AES_SUCCEEDED)
	{
	    printf("aligned memory copy error!\n");
			padlock_aligned_mfree( buf_aligned_mctx);
	    return -1;
	}
    
	res = padlock_aes_aligned_encrypt(p_key, key_len, mode, buf_aligned_mctx, temp_iv);
	if(res != AES_SUCCEEDED)
	{
	    print_ace_error(res);
			padlock_aligned_mfree( buf_aligned_mctx);
	    return -1;
	}
    
	// copy the encrypted result from aligned buffer to scratch
	res = padlock_aligned_memcpy_from(buf_aligned_mctx, scratch, nbytes);
	if(res != AES_SUCCEEDED)
	{
	    printf("aligned memory copy error!\n");
			padlock_aligned_mfree( buf_aligned_mctx);
	    return -1;
	}
    }
    // verify the result of encryption
    if (memcmp (scratch, p_cipher, nbytes))
    {
	printf("%s mode aligned AES-%s encryption test failed.\n",cipher_mode,cipher_key);
    }
    else 
    {
	printf("%s mode aligned AES-%s encryption test ok\n",cipher_mode,cipher_key);
    }

    //print_star();
    /////////////////////////////////////////////////////////////////////
    
    // because the temp_iv has been updated 
    // we have to restore orig_iv to it here
    memcpy(temp_iv, orig_iv, 16);

    if (in_block){
	// operate the data block by block.
	int pos = 0;
		int length = nbytes;
	while (length >= 16){
	    // copy one block of data to be decrypted to aligned buffer
	    res = padlock_aligned_memcpy_to(buf_aligned_mctx, p_cipher + pos, 16);
	    if(res != AES_SUCCEEDED)
	    {	 
		printf("aligned memory copy error!\n");
				padlock_aligned_mfree( buf_aligned_mctx);
		return -1;
	    }
    
	    // call ACE aligned aes decryption API
	    res = padlock_aes_aligned_decrypt(p_key, key_len, mode, buf_aligned_mctx, temp_iv);
	    if(res != AES_SUCCEEDED)
	    {
		print_ace_error(res);
				padlock_aligned_mfree( buf_aligned_mctx);
		return -1;
	    }
	
	    // copy the decrypted result from aligned buffer to scratch
	    res = padlock_aligned_memcpy_from(buf_aligned_mctx, scratch + pos, 16);
	    if(res != AES_SUCCEEDED)
	    {
		printf("aligned memory copy error!\n");
				padlock_aligned_mfree( buf_aligned_mctx);
		return -1;
	    }
	    length -= 16;
	    pos += 16;
	}
    }
    else{
	// copy data to be decrypted to aligned buffer
	res = padlock_aligned_memcpy_to(buf_aligned_mctx, p_cipher, nbytes);
	if(res != AES_SUCCEEDED)
	{
	    printf("aligned memory copy error!\n");
			padlock_aligned_mfree( buf_aligned_mctx);
	    return -1;
	}
    
	// call ACE aligned aes decryption API
	res = padlock_aes_aligned_decrypt(p_key, key_len, mode, buf_aligned_mctx, temp_iv);
	if(res != AES_SUCCEEDED)
	{
	    print_ace_error(res);
			padlock_aligned_mfree( buf_aligned_mctx);
	    return -1;
	}
    
	// copy the decrypted result from aligned buffer to scratch
	res = padlock_aligned_memcpy_from(buf_aligned_mctx, scratch, nbytes);
	if(res != AES_SUCCEEDED)
	{
	    printf("aligned memory copy error!\n");
			padlock_aligned_mfree( buf_aligned_mctx);
	    return -1;
	}
    }
    // verify the result of decryption
    if (memcmp (scratch, p_plain, nbytes))
    {
	printf("%s mode aligned AES-%s decryption test failed.\n",cipher_mode,cipher_key);
    }
    else 
    {
	printf("%s mode aligned AES-%s decryption test ok\n",cipher_mode,cipher_key);
    }

    // destroy the aligned buffer context
    padlock_aligned_mfree( buf_aligned_mctx);
    
    //print_star();

    return 0;
}

//  test VIA Padlock SDK ACE fast aes API
static int
test_padlock_fast_aes(ACE_AES_MODE mode, KEY_LENGTH key_len, int nbytes, int in_block)
{
    unsigned char *p_temp_buf = NULL;
    unsigned char *p_aligned_buf = NULL;
    
    char cipher_mode[10]= {0,};
    char cipher_key[10] = {0,};
    
    unsigned char *p_key = NULL;
    unsigned char *p_plain = NULL;
    unsigned char *p_cipher = NULL;
    unsigned char temp_iv[16]={0,};
    unsigned char orig_iv[16]={0,};
    
    AES_RESULT res;

    switch (mode)
    {
	case ACE_AES_CTR:	memcpy(cipher_mode,"CTR",3);
			    p_plain = (unsigned char *)ctr_aes_plain;
			    memcpy(orig_iv,(unsigned char *)ctr_aes_iv,16);
			    switch(key_len)
			    {
			    case KEY_128BITS:	    memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ctr_aes128_key;
						    p_cipher = (unsigned char *)ctr_aes128_cipher;
						    break;
			    case KEY_192BITS:	     memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ctr_aes192_key;
						    p_cipher = (unsigned char *)ctr_aes192_cipher;
						    break;
			    case KEY_256BITS:	     memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ctr_aes256_key;
						    p_cipher = (unsigned char *)ctr_aes256_cipher;
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			    break;
    default :		     printf("Invalid Cipher Mode Error!\n");
			    return -1;
    }
    
    print_star();
    printf("%s mode fast AES %sbits key cipher test:\n",cipher_mode,cipher_key);
    //print_star();

    // malloc temporary buffer for later use
    p_temp_buf = (unsigned char *)malloc((nbytes + 16));
    if(p_temp_buf == NULL)
    {
	printf("Fail to malloc %d bytes memory!\n",(nbytes + 16));
	return -1;
    }
    
    // get address aligned buffer from temporary buffer
    p_aligned_buf = (unsigned char *)((((unsigned long)p_temp_buf) + 15 )&(~15UL));
    
    // because the temp_iv will be updated 
    // we have to reserve it to orig_iv and copy it to temp_iv here
    memcpy(temp_iv, orig_iv, 16);

    if (in_block){
	// operate the data block by block.
	int pos = 0;
		int length = nbytes;
	while (length >= 16){
	    // copy one block of the data to be encrypted to aligned buffer
	    memcpy(p_aligned_buf, p_plain + pos, 16);
	    // call ACE fast aes encryption API 
	    res = padlock_aes_fast_encrypt(p_key, key_len, mode, p_aligned_buf, p_aligned_buf, 16, temp_iv);
	    if(res != AES_SUCCEEDED)
	    {
		print_ace_error(res);
				free(p_temp_buf);
		return -1;
	    }
	    // copy the encryption result to scratch
	    memcpy(scratch + pos, p_aligned_buf, 16);
	    length -= 16;
	    pos += 16;
	}
    }
    else{
	// copy the data to be encrypted to aligned buffer
	memcpy(p_aligned_buf, p_plain,nbytes);
	
	// call ACE fast aes encryption API 
	res = padlock_aes_fast_encrypt(p_key, key_len, mode, p_aligned_buf, p_aligned_buf, nbytes, temp_iv);
	if(res != AES_SUCCEEDED)
	{
	    print_ace_error(res);
			free(p_temp_buf);
	    return -1;
	}
    
	// copy the encryption result to scratch
	memcpy(scratch, p_aligned_buf, nbytes);
    }
    

    // verify the result of encryption
    if (memcmp (scratch, p_cipher, nbytes))
    {
	printf("%s mode fast AES-%s encryption test failed.\n",cipher_mode,cipher_key);
    }
    else 
    {
	printf("%s mode fast AES-%s encryption test ok\n",cipher_mode,cipher_key);
    }

    //print_star();
    /////////////////////////////////////////////////////////////////////

    // because the temp_iv has been updated 
    // we have to restore orig_iv to it here
    memcpy(temp_iv, orig_iv, 16);

    if (in_block){
	// operate the data block by block
	int pos = 0;
		int length = nbytes;
	while (length >= 16){
	    // copy one block of the data to be decrypted to aligned buffer
	    memcpy(p_aligned_buf, p_cipher + pos, 16);
	    // call ACE fast aes encryption API 
	    res = padlock_aes_fast_decrypt(p_key, key_len, mode, p_aligned_buf, p_aligned_buf, 16, temp_iv);
	    if(res != AES_SUCCEEDED)
	    {
		print_ace_error(res);
				free(p_temp_buf);
		return -1;
	    }
	    // copy the decryption result to scratch
	    memcpy(scratch + pos, p_aligned_buf, 16);
	    length -= 16;
	    pos += 16;
	}
    }
    else {
	// copy the data to be decrypted to aligned buffer
	memcpy(p_aligned_buf, p_cipher, nbytes);
    
	// call ACE fast aes decryption API 
	res = padlock_aes_fast_decrypt(p_key, key_len, mode, p_aligned_buf, p_aligned_buf, nbytes, temp_iv);
	if(res != AES_SUCCEEDED)
	{
	    print_ace_error(res);
			free(p_temp_buf);
	    return -1;
	}

	// copy the decryption result to scratch
	memcpy(scratch, p_aligned_buf, nbytes);
    }

    // verify the result of decryption
    if (memcmp (scratch, p_plain, nbytes))
    {
	printf("%s mode fast AES-%s decryption test failed.\n",cipher_mode,cipher_key);
    }
    else 
    {
	printf("%s mode fast AES-%s decryption test ok\n",cipher_mode,cipher_key);
    }

    // free temporary buffer
    free( p_temp_buf);
    
    //print_star();

    return 0;
}

// test VIA Padlock SDK ACE plain aes API
static int
test_padlock_aes_with_large_size(ACE_AES_MODE mode, KEY_LENGTH key_len, int nbytes)
{
	struct ace_aes_context *ctx = NULL;
	char cipher_mode[10]= {0,};
	char cipher_key[10] = {0,};
	
	unsigned char *p_key;
	unsigned char *p_plain = (unsigned char*)malloc(nbytes+64);
	unsigned char *p_cipher = (unsigned char*)malloc(nbytes+64);
	unsigned char *p_src = (unsigned char*)malloc(nbytes+64);

	unsigned char temp_iv[16]={0,};
	unsigned char orig_iv[16]={0,};

	AES_RESULT res;
	
	if(NULL == p_plain || NULL == p_cipher || NULL == p_src)
	{
		goto lable_return;
	}

	memset(p_plain, 0x23, nbytes);
	memset(p_cipher, 0, nbytes);


	switch (mode)
	{
	case ACE_AES_ECB:  memcpy(cipher_mode,"ECB",3);
							switch(key_len)
							{
							case KEY_128BITS:		memcpy(cipher_key,"128",3);
													p_key = (unsigned char *)ecb_aes128_key;
													break;
							case KEY_192BITS:		memcpy(cipher_key,"192",3);
													p_key = (unsigned char *)ecb_aes192_key;
													break;
							case KEY_256BITS:		memcpy(cipher_key,"256",3);
													p_key = (unsigned char *)ecb_aes256_key;
													break;
							default:				printf("Invalid Key Length Error!\n");
													goto lable_return;
							}
							break;
	case ACE_AES_CBC:  memcpy(cipher_mode,"CBC",3);
							memcpy(orig_iv,(unsigned char *)cbc_aes_iv,16);
							switch(key_len)
							{
							case KEY_128BITS:		memcpy(cipher_key,"128",3);
													p_key = (unsigned char *)cbc_aes128_key;
													break;
							case KEY_192BITS:		memcpy(cipher_key,"192",3);
													p_key = (unsigned char *)cbc_aes192_key;
													break;
							case KEY_256BITS:		memcpy(cipher_key,"256",3);
													p_key = (unsigned char *)cbc_aes256_key;
													break;
							default:				printf("Invalid Key Length Error!\n");
													goto lable_return;
							}
							break;
	case ACE_AES_CFB128:  memcpy(cipher_mode,"CFB128",6);
							memcpy(orig_iv,(unsigned char *)cfb128_aes_iv,16);
							switch(key_len)
							{
							case KEY_128BITS:		memcpy(cipher_key,"128",3);
													p_key = (unsigned char *)cfb128_aes128_key;
													break;
							case KEY_192BITS:		memcpy(cipher_key,"192",3);
													p_key = (unsigned char *)cfb128_aes192_key;
													break;
							case KEY_256BITS:		memcpy(cipher_key,"256",3);
													p_key = (unsigned char *)cfb128_aes256_key;
													break;
							default:				printf("Invalid Key Length Error!\n");
													goto lable_return;
							}
							break;
	case ACE_AES_OFB128:  memcpy(cipher_mode,"OFB128",6);
							memcpy(orig_iv,(unsigned char *)ofb_aes_iv,16);
							switch(key_len)
							{
							case KEY_128BITS:		memcpy(cipher_key,"128",3);
													p_key = (unsigned char *)ofb_aes128_key;
													break;
							case KEY_192BITS:		memcpy(cipher_key,"192",3);
													p_key = (unsigned char *)ofb_aes192_key;
													break;
							case KEY_256BITS:		memcpy(cipher_key,"256",3);
													p_key = (unsigned char *)ofb_aes256_key;
													break;
							default:				printf("Invalid Key Length Error!\n");
													goto lable_return;
							}
							break;
	case ACE_AES_CTR:		memcpy(cipher_mode,"CTR",3);
							memcpy(orig_iv,(unsigned char *)ctr_aes_iv,16);
							switch(key_len)
							{
							case KEY_128BITS:		memcpy(cipher_key,"128",3);
													p_key = (unsigned char *)ctr_aes128_key;
													break;
							case KEY_192BITS:		memcpy(cipher_key,"192",3);
													p_key = (unsigned char *)ctr_aes192_key;
													break;
							case KEY_256BITS:		memcpy(cipher_key,"256",3);
													p_key = (unsigned char *)ctr_aes256_key;
													break;
							default:				printf("Invalid Key Length Error!\n");
													goto lable_return;
							}
							break;
	default :				printf("Invalid Cipher Mode Error!\n");
							goto lable_return;
	}
	
	//print_star();
	printf("%s mode plain AES %sbits key cipher test:\n",cipher_mode,cipher_key);
	//print_star();

	// create the ace aes cipher context 
	ctx = padlock_aes_begin();
	if(NULL == ctx)
	{
		print_ace_error(AES_FAILED);
		goto lable_return;
	}
	// set cipher key
	res = padlock_aes_setkey( ctx, p_key, key_len);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return;
	}
	
	// because the iv will be updated by the plain aes encryption and decryption API
	// here we reserve it in the orig_iv
	memcpy(temp_iv, orig_iv, 16);

	// set cipher mode and iv
	res = padlock_aes_setmodeiv( ctx, mode, temp_iv);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return;
	}
		
	// call ACE plain aes encryption API
	res = padlock_aes_encrypt( ctx, p_plain, p_cipher, nbytes);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return;
	}
	
	
	// verify the result of encryption
	if (memcmp (p_plain, p_cipher, nbytes))
	{
	printf("%s mode plain AES-%s encryption test ok.\n",cipher_mode,cipher_key);
	}
    else
	{
		printf("%s mode plain AES-%s encryption test failed\n",cipher_mode,cipher_key);
	}

	//print_star();
	
	/////////////////////////////////////////////////////////////////////
	
	// because the temp_iv has been updated 
	// we have to restore orig_iv to it here
	memcpy(temp_iv, orig_iv, 16);

	// reset iv for decrytion
	res = padlock_aes_setmodeiv( ctx, mode, temp_iv);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return;
	}

	// call ACE plain aes decryption API
	memcpy(p_src, p_cipher, nbytes);
	res = padlock_aes_decrypt( ctx, p_src, p_cipher, nbytes);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return;
	}
	
	
	// verify the result of decryption
	if (memcmp (p_cipher, p_plain, nbytes))
	{
	printf("%s mode plain AES-%s decryption test failed.\n",cipher_mode,cipher_key);
    }
	else 
	{
		printf("%s mode plain AES-%s decryption test ok\n",cipher_mode,cipher_key);
	}

lable_return:
	// destroy the ace aes cipher context
	if(ctx)
		padlock_aes_close( ctx);
    free(p_plain);
	free(p_cipher);
	free(p_src);

	//print_star();

	return 0;
}

// test VIA Padlock SDK ACE aligned aes API
static int
test_padlock_aligned_aes_with_large_size(ACE_AES_MODE mode, KEY_LENGTH key_len, int nbytes)
{
	struct aligned_memory_context *buf_aligned_mctx = NULL;

	char cipher_mode[10]= {0,};
	char cipher_key[10] = {0,};
	
	unsigned char *p_key = NULL;
	unsigned char *p_plain = (unsigned char*)malloc(nbytes);
	unsigned char *p_cipher = (unsigned char*)malloc(nbytes);
	unsigned char temp_iv[16]={0,};
	unsigned char orig_iv[16]={0,};
	
	AES_RESULT res;

	if(NULL == p_plain || NULL == p_cipher)
	{
		goto lable_return_aligned;
	}

	memset(p_plain, 1, nbytes);
	memset(p_cipher, 0, nbytes);

	switch (mode)
	{
	case ACE_AES_ECB:	memcpy(cipher_mode,"ECB",3);
				switch(key_len)
				{
				case KEY_128BITS:		memcpy(cipher_key,"128",3);
								p_key = (unsigned char *)ecb_aes128_key;
								break;
				case KEY_192BITS:		memcpy(cipher_key,"192",3);
								p_key = (unsigned char *)ecb_aes192_key;
								break;
				case KEY_256BITS:		memcpy(cipher_key,"256",3);
								p_key = (unsigned char *)ecb_aes256_key;
								break;
				default:			printf("Invalid Key Length Error!\n");
								goto lable_return_aligned;
				}
				break;
	case ACE_AES_CBC:  memcpy(cipher_mode,"CBC",3);
				memcpy(orig_iv,(unsigned char *)cbc_aes_iv,16);
				switch(key_len)
				{
				case KEY_128BITS:		memcpy(cipher_key,"128",3);
								p_key = (unsigned char *)cbc_aes128_key;
								break;
				case KEY_192BITS:		memcpy(cipher_key,"192",3);
								p_key = (unsigned char *)cbc_aes192_key;
								break;
				case KEY_256BITS:		memcpy(cipher_key,"256",3);
								p_key = (unsigned char *)cbc_aes256_key;
								break;
				default:			printf("Invalid Key Length Error!\n");
								goto lable_return_aligned;
				}
				break;
	case ACE_AES_CFB128:  memcpy(cipher_mode,"CFB128",6);
				memcpy(orig_iv,(unsigned char *)cfb128_aes_iv,16);
				switch(key_len)
				{
				case KEY_128BITS:		memcpy(cipher_key,"128",3);
								p_key = (unsigned char *)cfb128_aes128_key;
								break;
				case KEY_192BITS:		memcpy(cipher_key,"192",3);
								p_key = (unsigned char *)cfb128_aes192_key;
								break;
				case KEY_256BITS:		memcpy(cipher_key,"256",3);
								p_key = (unsigned char *)cfb128_aes256_key;
								break;
				default:			printf("Invalid Key Length Error!\n");
								goto lable_return_aligned;
				}
				break;
	case ACE_AES_OFB128:  memcpy(cipher_mode,"OFB128",6);
				memcpy(orig_iv,(unsigned char *)ofb_aes_iv,16);
				switch(key_len)
				{
				case KEY_128BITS:		memcpy(cipher_key,"128",3);
								p_key = (unsigned char *)ofb_aes128_key;
								break;
				case KEY_192BITS:		memcpy(cipher_key,"192",3);
								p_key = (unsigned char *)ofb_aes192_key;
								break;
				case KEY_256BITS:		memcpy(cipher_key,"256",3);
								p_key = (unsigned char *)ofb_aes256_key;
								break;
				default:			printf("Invalid Key Length Error!\n");
								goto lable_return_aligned;
				}
				break;
	case ACE_AES_CTR:	memcpy(cipher_mode,"CTR",3);
				memcpy(orig_iv,(unsigned char *)ctr_aes_iv,16);
				switch(key_len)
				{
				case KEY_128BITS:		memcpy(cipher_key,"128",3);
								p_key = (unsigned char *)ctr_aes128_key;
								break;
				case KEY_192BITS:		memcpy(cipher_key,"192",3);
								p_key = (unsigned char *)ctr_aes192_key;
								break;
				case KEY_256BITS:		memcpy(cipher_key,"256",3);
								p_key = (unsigned char *)ctr_aes256_key;
								break;
				default:			printf("Invalid Key Length Error!\n");
								goto lable_return_aligned;
				}
				break;
	default :		printf("Invalid Cipher Mode Error!\n");
				goto lable_return_aligned;
	}
	
	//print_star();
	printf("%s mode aligned AES %sbits key cipher test:\n",cipher_mode,cipher_key);
	//print_star();

	// create address aligned buffer context
	buf_aligned_mctx = padlock_aligned_malloc(nbytes);
	
	if(NULL == buf_aligned_mctx)
	{
		print_ace_error(AES_FAILED);
		goto lable_return_aligned;
	}
	// copy data to be encrypted to aligned buffer
	res = padlock_aligned_memcpy_to(buf_aligned_mctx, p_plain, nbytes);
	if(res != AES_SUCCEEDED)
	{
		printf("aligned memory copy error!\n");
		goto lable_return_aligned;
	}
	
	// because the temp_iv will be updated 
	// we have to reserve it to orig_iv and copy it to temp_iv here
	memcpy(temp_iv, orig_iv, 16);

	// call ACE aligned aes encryption API 
	res = padlock_aes_aligned_encrypt(p_key, key_len, mode, buf_aligned_mctx, temp_iv);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return_aligned;
	}
	

	// copy the encrypted result from aligned buffer to scratch
	res = padlock_aligned_memcpy_from(buf_aligned_mctx, p_cipher, nbytes);
	if(res != AES_SUCCEEDED)
	{
		printf("aligned memory copy error!\n");
		goto lable_return_aligned;
	}
	
	// verify the result of encryption
	if (memcmp (p_plain, p_cipher, nbytes))
	{
		printf("%s mode aligned AES-%s encryption test ok.\n",cipher_mode,cipher_key);
	}
	else 
	{
		printf("%s mode aligned AES-%s encryption test failed\n",cipher_mode,cipher_key);
	}

	//print_star();
	/////////////////////////////////////////////////////////////////////
	
	// copy data to be decrypted to aligned buffer
	res = padlock_aligned_memcpy_to(buf_aligned_mctx, p_cipher, nbytes);
	if(res != AES_SUCCEEDED)
	{
		printf("aligned memory copy error!\n");
		goto lable_return_aligned;
	}
	
	// because the temp_iv has been updated 
	// we have to restore orig_iv to it here
	memcpy(temp_iv, orig_iv, 16);
		
	// call ACE aligned aes decryption API
	res = padlock_aes_aligned_decrypt(p_key, key_len, mode, buf_aligned_mctx, temp_iv);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return_aligned;
	}
	
	
	// copy the decrypted result from aligned buffer to scratch
	res = padlock_aligned_memcpy_from(buf_aligned_mctx, p_cipher, nbytes);
	if(res != AES_SUCCEEDED)
	{
		printf("aligned memory copy error!\n");
		goto lable_return_aligned;
	}
	
	// verify the result of decryption
	if (memcmp (p_cipher, p_plain, nbytes))
	{
		printf("%s mode aligned AES-%s decryption test failed.\n",cipher_mode,cipher_key);
	}
	else 
	{
		printf("%s mode aligned AES-%s decryption test ok\n",cipher_mode,cipher_key);
	}

lable_return_aligned:

	// destroy the aligned buffer context
	if(buf_aligned_mctx)
		padlock_aligned_mfree( buf_aligned_mctx);
    free(p_plain);
	free(p_cipher);

    
	//print_star();

	return 0;
}

//  test VIA Padlock SDK ACE fast aes API
static int
test_padlock_fast_aes_with_large_size(ACE_AES_MODE mode, KEY_LENGTH key_len, int nbytes)
{
	unsigned char *p_temp_sbuf = NULL; // for src
	unsigned char *p_temp_dbuf = NULL; // for dst
	unsigned char *p_aligned_sbuf = NULL;
	unsigned char *p_aligned_dbuf = NULL;
	char cipher_mode[10]= {0,};
	char cipher_key[10] = {0,};
	
	unsigned char *p_key = NULL;
	unsigned char *p_plain = (unsigned char*)malloc(nbytes+64);
	unsigned char *p_cipher = (unsigned char*)malloc(nbytes+64);
	unsigned char temp_iv[16]={0,};
	unsigned char orig_iv[16]={0,};
	
	AES_RESULT res;
	
	if(NULL == p_plain || NULL == p_cipher)
	{
		goto lable_return_fast;
	}

	memset(p_plain, 1, nbytes);
	memset(p_cipher, 0, nbytes);

	switch (mode)
	{
	case ACE_AES_CTR:	
			{
			   memcpy(cipher_mode,"CTR",3);

			    switch(key_len)
			    {
			    case KEY_128BITS:	    memcpy(cipher_key,"128",3);
						    p_key = (unsigned char *)ctr_aes128_key;
						    
						    break;
			    case KEY_192BITS:	    memcpy(cipher_key,"192",3);
						    p_key = (unsigned char *)ctr_aes192_key;
						    
						    break;
			    case KEY_256BITS:	    memcpy(cipher_key,"256",3);
						    p_key = (unsigned char *)ctr_aes256_key;
						    
						    break;
			    default:		    printf("Invalid Key Length Error!\n");
						    return -1;
			    }
			} 
			break;
	case ACE_AES_ECB:  memcpy(cipher_mode,"ECB",3);
			switch(key_len)
			{
			case KEY_128BITS:		memcpy(cipher_key,"128",3);
							p_key = (unsigned char *)ecb_aes128_key;
							break;
			case KEY_192BITS:		memcpy(cipher_key,"192",3);
							p_key = (unsigned char *)ecb_aes192_key;
							break;
			case KEY_256BITS:		memcpy(cipher_key,"256",3);
							p_key = (unsigned char *)ecb_aes256_key;
							break;
			default:			printf("Invalid Key Length Error!\n");
							goto lable_return_fast;
			}
			break;
	case ACE_AES_CBC:  memcpy(cipher_mode,"CBC",3);
			memcpy(orig_iv,(unsigned char *)cbc_aes_iv,16);
			switch(key_len)
			{
			case KEY_128BITS:		memcpy(cipher_key,"128",3);
							p_key = (unsigned char *)cbc_aes128_key;
							break;
			case KEY_192BITS:		memcpy(cipher_key,"192",3);
							p_key = (unsigned char *)cbc_aes192_key;
							break;
			case KEY_256BITS:		memcpy(cipher_key,"256",3);
							p_key = (unsigned char *)cbc_aes256_key;
							break;
			default:			printf("Invalid Key Length Error!\n");
							goto lable_return_fast;
			}
			break;
	case ACE_AES_CFB128:  memcpy(cipher_mode,"CFB128",6);
			memcpy(orig_iv,(unsigned char *)cfb128_aes_iv,16);
			switch(key_len)
			{
			case KEY_128BITS:		memcpy(cipher_key,"128",3);
							p_key = (unsigned char *)cfb128_aes128_key;
							break;
			case KEY_192BITS:		memcpy(cipher_key,"192",3);
							p_key = (unsigned char *)cfb128_aes192_key;
							break;
			case KEY_256BITS:		memcpy(cipher_key,"256",3);
							p_key = (unsigned char *)cfb128_aes256_key;
							break;
			default:			printf("Invalid Key Length Error!\n");
							goto lable_return_fast;
			}
			break;
	case ACE_AES_OFB128:  memcpy(cipher_mode,"OFB128",6);
			memcpy(orig_iv,(unsigned char *)ofb_aes_iv,16);
			switch(key_len)
			{
			case KEY_128BITS:		memcpy(cipher_key,"128",3);
							p_key = (unsigned char *)ofb_aes128_key;
							break;
			case KEY_192BITS:		memcpy(cipher_key,"192",3);
							p_key = (unsigned char *)ofb_aes192_key;
							break;
			case KEY_256BITS:		memcpy(cipher_key,"256",3);
							p_key = (unsigned char *)ofb_aes256_key;
							break;
			default:			printf("Invalid Key Length Error!\n");
							goto lable_return_fast;
			}
			break;
	default :	printf("Invalid Cipher Mode Error!\n");
			goto lable_return_fast;
	}
	
	//print_star();
	printf("%s mode fast AES %sbits key cipher test:\n",cipher_mode,cipher_key);
	//print_star();

	// malloc temporary buffer for later use
	p_temp_sbuf = (unsigned char *)malloc((nbytes + 16));
	if(p_temp_sbuf == NULL)
	{
		printf("Fail to malloc %d bytes memory!\n",(nbytes + 16));
		goto lable_return_fast;
	}
	p_temp_dbuf = (unsigned char *)malloc((nbytes + 16));
	if(p_temp_dbuf == NULL)
	{
		printf("Fail to malloc %d bytes memory!\n",(nbytes + 16));
		goto lable_return_fast;
	}
	
	
	// get address aligned buffer from temporary buffer
	p_aligned_sbuf = (unsigned char *)((((unsigned long)p_temp_sbuf) + 15 )&(~15UL));
	p_aligned_dbuf = (unsigned char *)((((unsigned long)p_temp_dbuf) + 15 )&(~15UL));
	
	// copy the data to be encrypted to aligned buffer
	memcpy(p_aligned_sbuf, p_plain,nbytes);
	
	// because the temp_iv will be updated 
	// we have to reserve it to orig_iv and copy it to temp_iv here
	memcpy(temp_iv, orig_iv, 16);
	
	// call ACE fast aes encryption API 
	res = padlock_aes_fast_encrypt(p_key, key_len, mode, p_aligned_sbuf, p_aligned_dbuf, nbytes, temp_iv);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return_fast;
	}
	
	// copy the encryption result to scratch
	memcpy(p_cipher, p_aligned_dbuf, nbytes);
	

	// verify the result of encryption
	if (memcmp (p_cipher, p_plain, nbytes))
	{
		printf("%s mode fast AES-%s encryption test ok.\n",cipher_mode,cipher_key);
	}
	else 
	{
		printf("%s mode fast AES-%s encryption test failed\n",cipher_mode,cipher_key);
	}

	//print_star();
	/////////////////////////////////////////////////////////////////////
	
	// copy the data to be decrypted to aligned buffer
	memcpy(p_aligned_sbuf, p_cipher, nbytes);
	
	// because the temp_iv has been updated 
	// we have to restore orig_iv to it here
	memcpy(temp_iv, orig_iv, 16);

	// call ACE fast aes decryption API 
	res = padlock_aes_fast_decrypt(p_key, key_len, mode, p_aligned_sbuf, p_aligned_dbuf, nbytes, temp_iv);
	if(res != AES_SUCCEEDED)
	{
		print_ace_error(res);
		goto lable_return_fast;
	}

	// copy the decryption result to scratch
	memcpy(p_cipher, p_aligned_dbuf, nbytes);


	// verify the result of decryption
	if (memcmp (p_cipher, p_plain, nbytes))
	{
		 printf("%s mode fast AES-%s decryption test failed.\n",cipher_mode,cipher_key);
	}
	else 
	{
		printf("%s mode fast AES-%s decryption test ok\n",cipher_mode,cipher_key);
	}

lable_return_fast:

	// free temporary buffer
	if(p_temp_sbuf)
		free( p_temp_sbuf);
	if(p_temp_dbuf)
		free( p_temp_dbuf);
	free(p_cipher);
	free(p_plain);
 
	//print_star();

	return 0;
}


void test_data_size(int low, int high)
{
    ACE_AES_MODE mode;
	KEY_LENGTH key_len;

	int nbytes = low;
	char in = 0;

	while (nbytes <= high){
		print_star();

		if (nbytes /1024)
			printf(" Test data length =   [ %d K ]\n", nbytes/1024);
		else
			printf(" Test data length =   [ %d  ]\n", nbytes);
		print_star();
		printf("Press any key to start testing: ");
	    scanf("%c", &in);

		printf("Begin to test Padlock SDK aes API functions:\n");

		mode = ACE_AES_ECB;
		key_len = KEY_128BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_ECB;
		key_len = KEY_192BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_ECB;
		key_len = KEY_256BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CBC;
		key_len = KEY_128BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_CBC;
		key_len = KEY_192BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CBC;
		key_len = KEY_256BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_128BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_192BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_256BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_128BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_192BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_256BITS;
		test_padlock_aes_with_large_size(mode,key_len,nbytes);

		if (ace2_available)
		{
			mode = ACE_AES_CTR;
			key_len = KEY_128BITS;
			test_padlock_aes_with_large_size(mode,key_len,nbytes);

			mode = ACE_AES_CTR;
			key_len = KEY_192BITS;
			test_padlock_aes_with_large_size(mode,key_len,nbytes);

			mode = ACE_AES_CTR;
			key_len = KEY_256BITS;
			test_padlock_aes_with_large_size(mode,key_len,nbytes);
		}
		//////////////////////////////////////////////////////////////////
		print_star();
		printf("Begin to test Padlock SDK aligned aes API functions:\n");

		mode = ACE_AES_ECB;
		key_len = KEY_128BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_ECB;
		key_len = KEY_192BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_ECB;
		key_len = KEY_256BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CBC;
		key_len = KEY_128BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_CBC;
		key_len = KEY_192BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CBC;
		key_len = KEY_256BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_128BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_192BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_256BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_128BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_192BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_256BITS;
		test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

		if (ace2_available)
		{
			mode = ACE_AES_CTR;
			key_len = KEY_128BITS;
			test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);
		
			mode = ACE_AES_CTR;
			key_len = KEY_192BITS;
			test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);

			mode = ACE_AES_CTR;
			key_len = KEY_256BITS;
			test_padlock_aligned_aes_with_large_size(mode,key_len,nbytes);
		}
		///////////////////////////////////////////////////////////////////////////////////////

		print_star();
		printf("Begin to test Padlock SDK fast aes API functions:\n");

		mode = ACE_AES_ECB;
		key_len = KEY_128BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_ECB;
		key_len = KEY_192BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_ECB;
		key_len = KEY_256BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CBC;
		key_len = KEY_128BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_CBC;
		key_len = KEY_192BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CBC;
		key_len = KEY_256BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_128BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_192BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_CFB128;
		key_len = KEY_256BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_128BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);

		mode = ACE_AES_OFB128;
		key_len = KEY_192BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);
		
		mode = ACE_AES_OFB128;
		key_len = KEY_256BITS;
		test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);


		if (ace2_available)
		{
			mode = ACE_AES_CTR;
			key_len = KEY_128BITS;
			test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);
	
			mode = ACE_AES_CTR;
			key_len = KEY_192BITS;
			test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);
		
			mode = ACE_AES_CTR;
			key_len = KEY_256BITS;
			test_padlock_fast_aes_with_large_size(mode,key_len,nbytes);
		}
		nbytes *=2; 

	}
}

int aes_test()
{

    ACE_AES_MODE mode;
    KEY_LENGTH key_len;
    int nbytes = 64;
    char in;


    print_star();
    printf("Begin to test Padlock SDK ACE AES API functions:\n");
    print_star();

    // Padlock SDK ACE AES API
    ace_available = padlock_ace_available();
    if(ace_available)
    {
	printf("VIA ACE hardware is available!\n");
    }
    else
    {
	printf("VIA ACE hardware isn't available!\n");
	return -1;
    }
    ace2_available = padlock_ace2_available();
    if(ace2_available)
    {
	printf("VIA ACE2 hardware is available!\n");
    }
    else
    {
	printf("VIA ACE2 hardware isn't available!\n");
    }

    print_star();

    if (MAX_SIZE /1024)
	printf("Begin to test the AES API with data size from %d Bytes to %dK  bytes, \n \
		Each time double the size\n",MIN_SIZE,MAX_SIZE/1024);
    else
	printf("Begin to test the AES API with data size from %d Bytes to %d  bytes, \n \
		Each time double the size\n",MIN_SIZE,MAX_SIZE);

    printf("Press any key to start date size testing: ");
    scanf("%c", &in);
    test_data_size(MIN_SIZE, MAX_SIZE);

    print_star();

    printf("Press any key to continue AES API testing: ");
    scanf("%c", &in);

    mode = ACE_AES_ECB;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_ECB;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_ECB;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CBC;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_CBC;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CBC;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,0);

    if (ace2_available)
    {
	mode = ACE_AES_CTR;
	key_len = KEY_128BITS;
	test_padlock_aes(mode,key_len,nbytes,0);

	mode = ACE_AES_CTR;
	key_len = KEY_192BITS;
	test_padlock_aes(mode,key_len,nbytes,0);

	mode = ACE_AES_CTR;
	key_len = KEY_256BITS;
	test_padlock_aes(mode,key_len,nbytes,0);
    }
    ////////////////////////////////////////////////////////////////////////////////////

    print_star();
    printf("Begin to test Padlock SDK ACE AES API functions block by block:\n");
    print_star();


    mode = ACE_AES_ECB;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_ECB;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_ECB;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CBC;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_CBC;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CBC;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_128BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_192BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_256BITS;
    test_padlock_aes(mode,key_len,nbytes,1);

    if (ace2_available)  
    {
	mode = ACE_AES_CTR;
	key_len = KEY_128BITS;
	test_padlock_aes(mode,key_len,nbytes,1);
 
	mode = ACE_AES_CTR;
	key_len = KEY_192BITS;
	test_padlock_aes(mode,key_len,nbytes,1);
    
	mode = ACE_AES_CTR;
	key_len = KEY_256BITS;
	test_padlock_aes(mode,key_len,nbytes,1);
    }
    //////////////////////////////////////////////////////////////////

    print_star();
    printf("Begin to test Padlock SDK aligned aes API functions:\n");

    mode = ACE_AES_ECB;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_ECB;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_ECB;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CBC;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_CBC;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CBC;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,0);

    if (ace2_available)
    {
	mode = ACE_AES_CTR;
	key_len = KEY_128BITS;
	test_padlock_aligned_aes(mode,key_len,nbytes,0);
 
	mode = ACE_AES_CTR;
	key_len = KEY_192BITS;
	test_padlock_aligned_aes(mode,key_len,nbytes,0);

	mode = ACE_AES_CTR;
	key_len = KEY_256BITS;
	test_padlock_aligned_aes(mode,key_len,nbytes,0);
    }
    //////////////////////////////////////////////////////////////////

    print_star();
    printf("Begin to test Padlock SDK aligned aes API functions block by block :\n");

    mode = ACE_AES_ECB;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_ECB;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_ECB;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CBC;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_CBC;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CBC;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_128BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_192BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_256BITS;
    test_padlock_aligned_aes(mode,key_len,nbytes,1);

    if (ace2_available)
    {
	mode = ACE_AES_CTR;
	key_len = KEY_128BITS;
	test_padlock_aligned_aes(mode,key_len,nbytes,1);

	mode = ACE_AES_CTR;
	key_len = KEY_192BITS;
	test_padlock_aligned_aes(mode,key_len,nbytes,1);

	mode = ACE_AES_CTR;
	key_len = KEY_256BITS;
	test_padlock_aligned_aes(mode,key_len,nbytes,1);
    }
    ///////////////////////////////////////////////////////////////////////////////////////

	print_star();
	printf("Begin to test Padlock SDK fast aes API functions:\n");

    mode = ACE_AES_ECB;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_ECB;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_ECB;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CBC;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_CBC;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CBC;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_CFB128;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);

    mode = ACE_AES_OFB128;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);
    
    mode = ACE_AES_OFB128;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,0);


    if (ace2_available)
    {
	mode = ACE_AES_CTR;
	key_len = KEY_128BITS;
	test_padlock_fast_aes(mode,key_len,nbytes,0);

	mode = ACE_AES_CTR;
	key_len = KEY_192BITS;
	test_padlock_fast_aes(mode,key_len,nbytes,0);
    
	mode = ACE_AES_CTR;
	key_len = KEY_256BITS;
	test_padlock_fast_aes(mode,key_len,nbytes,0);
    }
    ///////////////////////////////////////////////////////////////////////////////////////

    print_star();
    printf("Begin to test Padlock SDK fast aes API functions block by block:\n");

    mode = ACE_AES_ECB;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_ECB;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_ECB;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CBC;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_CBC;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CBC;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_CFB128;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_128BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    mode = ACE_AES_OFB128;
    key_len = KEY_192BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);
    
    mode = ACE_AES_OFB128;
    key_len = KEY_256BITS;
    test_padlock_fast_aes(mode,key_len,nbytes,1);

    if (ace2_available)
    {
	mode = ACE_AES_CTR;
	key_len = KEY_128BITS;
	test_padlock_fast_aes(mode,key_len,nbytes,1);

	mode = ACE_AES_CTR;
	key_len = KEY_192BITS;
	test_padlock_fast_aes(mode,key_len,nbytes,1);
    
	mode = ACE_AES_CTR;
	key_len = KEY_256BITS;
	test_padlock_fast_aes(mode,key_len,nbytes,1);
    }

    printf("Press any key to exit. ");
    scanf("%c", &in);

    return 0;
}
