#include "padlock.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <memory.h>

#ifdef _WIN32_WCE

#include <Winbase.h>

typedef long  clock_t;

#endif

#ifdef _WINDOWS
#include <windows.h>
#endif

#define CLOCKS_PER_SEC 1000 

#ifdef Linux
#define clock GetMicroSec
#else
#define clock GetTickCount
#endif


extern  void print_star();


void sha256_test()
{
	int k,p,x;
	char* tmp;
	static char *str[]={
    "abc",
    "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
    };
	printf("Begin SHA256 test:\n");
	for (k=0;k<2;++k)
	{
		printf("The %d data is %s\n",k+1,str[k]);
		print_star();
	}	


	for (p=0;p<2;++p)
	{
		x=strlen(str[p]);
		tmp=(char*)malloc(100);
		if(NULL == tmp)
		{
			printf("memory allocate error!\n");
			return;
		}
		memset(tmp,0,100);
		tmp[x]='\0';
		//print_star();
		printf("The result %d should be:\n",p+1);
		if (p==0)
		{
			printf("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
		}
		else
		{
			printf("248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
		}
		padlock_phe_sha256((unsigned char*)str[p], x, (unsigned char*)tmp);
		print_star();
		printf("The result is:\n");
		for(k=0;k<32;++k)
		{
			printf("%.2x",(unsigned char)tmp[k]);
		}
		print_star();
		free(tmp);
	}
	printf("End SHA256 test\n\n");
	return;
}

void sha1_test()
{
	int k,p,x;
	char* tmp;
	static char *str[]={
    "abc",
    "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
    };

	printf("Begin SHA1 test:\n");
	for (k=0;k<2;++k)
	{
		printf("The %d data is %s\n",k+1,str[k]);
		print_star();
	}	

	for (p=0;p<2;++p)
	{
		x=strlen(str[p]);
		tmp=(char*)malloc(100);
		if(NULL == tmp)
		{
			printf("memory allocate error!\n");
			return;
		}
		memset(tmp,0,100);
		tmp[x]='\0';
		//print_star();
		printf("The result %d should be:\n",p+1);
		if (p==0)
		{
			printf("a9993e364706816aba3e25717850c26c9cd0d89d");
		}
		else
		{
			printf("84983e441c3bd26ebaae4aa1f95129e5e54670f1");
		}
		padlock_phe_sha1((unsigned char*)str[p], x, (unsigned char*)tmp);
		print_star();
		printf("The result is:\n");
		for(k=0;k<20;++k)
		{
			printf("%.2x",(unsigned char)tmp[k]);
		}
		print_star();
		free(tmp);
	}
	printf("End SHA1 test:\n\n");
	return;
}

int phe_partial_available()
{
	return padlock_phe_partial_available();
}

void sha1_partial_test()
{
	int i,n,k;
	char* str[4]={
					"abc",
					"56byte01234567890123456789012345678901234567890123456789",
					"64B 012345678901234567890123456789012345678901234567890123456789",
					"100 bytes 012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789"};
	char* compare[4]={
						"a9993e364706816aba3e25717850c26c9cd0d89d",
						"d0ecd1b0dd6c10d95c155c7274ec9194e88a2940",
						"3c1aad4ab8ac3a5008f6ccb928e1a3211cecbb0d",
						"47cc0e6d3689acb6203aa96423cf7963eb25cc59"};
	char *dst = NULL;
	char *tmp = NULL;
	struct phe_sha_context *ctx1 =	NULL;

	dst = (char*)malloc(20);
	tmp = (char*)malloc(128);
	if(NULL == tmp || NULL == dst)
	{
		printf("memory allocate error!\n");
		return;
	}

	printf("End PARTIAL SHA1 test:\n\n");

	for(i=0;i<4;i++)
	{
		n = strlen(str[i]);

		memset(tmp,0,128);
		tmp[n]='\0';

		printf("The %d data is '%s'\n",i+1,str[i]);
		print_star();

		printf("The result %d should be:\n",i+1);

		printf("%s\n",(unsigned char*)compare[i]);

		ctx1 = padlock_phe_partial_sha1_init();

		for(k=0;k<n/64;k++)
			padlock_phe_partial_sha1_update(ctx1,((unsigned char*)str[i])+k*64,64);

		padlock_phe_partial_sha1_final(ctx1,((unsigned char*)str[i])+k*64,n%64,(unsigned char*)dst);

		print_star();
		printf("The result is:\n");
		for(k=0;k<20;++k)
		{
			printf("%.2x",(unsigned char)dst[k]);
		}
		print_star();
	}

	printf("End PARTIAL SHA1 test:\n\n");

	free(tmp);
	free(dst);
}

void sha256_partial_test()
{
	int i,n,k;
	char* str[4]={
					"abc",
					"56byte01234567890123456789012345678901234567890123456789",
					"64B 012345678901234567890123456789012345678901234567890123456789",
					"100 bytes 012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789"};
	char* compare[4]={
					"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
					"b300aecb8803b126d78de51b221192ccdfbc65dc1ebe10414c4873fdd4d639b0",
					"54874d6a28ba9cb69876d9ba10747e3c53786c488f817dfc1bc2c6d1ad2836d2",
					"b71f7fff653a759242a8e411fff0e407441a4a94f7833f91f9806c4468622d8e"
					};
	char *dst = NULL;
	char *tmp = NULL;
	struct phe_sha_context *ctx256 =	NULL;

	dst = (char*)malloc(32);
	tmp = (char*)malloc(128);
	if(NULL == tmp || NULL == dst)
	{
		printf("memory allocate error!\n");
		return;
	}

	printf("Begin PARTIAL SHA256 test:\n\n");

	for(i=0;i<4;i++)
	{
		n = strlen(str[i]);

		memset(tmp,0,128);
		tmp[n]='\0';

		printf("The %d data is '%s'\n",i+1,str[i]);
		print_star();

		printf("The result %d should be:\n",i+1);

		printf("%s\n",(unsigned char*)compare[i]);

		ctx256 = padlock_phe_partial_sha256_init();

		for(k=0;k<n/64;k++)
			padlock_phe_partial_sha256_update(ctx256,((unsigned char*)str[i])+k*64,64);

		padlock_phe_partial_sha256_final(ctx256,((unsigned char*)str[i])+k*64,n%64,(unsigned char*)dst);

		print_star();
		printf("The result is:\n");
		for(k=0;k<32;++k)
		{
			printf("%.2x",(unsigned char)dst[k]);
		}
		print_star();
	}

	printf("End PARTIAL SHA256 test:\n\n");

	free(tmp);
	free(dst);
}


int sha_file_test()
{
	clock_t start, finish;
	double duration = 0.0;
	double rate = 0.0;
	int k=0;
	char filename[20];
	long len;
	FILE* file=NULL;
	unsigned char* buffer=NULL;
	char tmp[64];
	memset(tmp,0,64);

	printf("********************************************************************\n");
	printf("input file to be tested:\n");
	printf("input: ");
	scanf("%s",filename);

	file=fopen(filename,"rb");
	if (!file)
	{
		printf("error when open file.\n");
		return 0;
	}
	fseek(file,0,SEEK_END);
	len=ftell(file);
	fseek(file,0,SEEK_SET);
	buffer=(unsigned char*)malloc(len+64);
	if(NULL == buffer)
	{
		printf("memory allocate error!\n");
		fclose(file);
		return 0;
	}
	memset(buffer,0,len);
	fread(buffer,sizeof(unsigned char),len,file);

	start=clock();
	for(k=0;k<100;++k)
	{
		padlock_phe_sha1((unsigned char*)buffer, len, (unsigned char*)tmp);
	}
	finish=clock();
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	rate = (double)len * 8.0 * 100.0 / (duration * 1024. * 1024. * 1024.);
	printf("********************************************************************\n");
	printf( "SHA1 time loop 100:\t\t%6.3f second  ", duration );
	printf( "%6.3f G bits/sec\n", rate);

	printf("SHA1 hash result:\t");
	for(k=0;k<20;++k)
	{
		printf("%.2x",(unsigned char)tmp[k]);
	}
	printf("\n");



	start=clock();
	for(k=0;k<100;++k)
	{
		padlock_phe_sha256((unsigned char*)buffer, len, (unsigned char*)tmp);
	}
	finish=clock();
	duration = (double)(finish - start) / CLOCKS_PER_SEC;
	rate = (double)len * 8.0 * 100.0 / (duration * 1024. * 1024. * 1024.);
	printf("********************************************************************\n");
	printf( "SHA256 time :\t\t%6.3f second  ", duration );
	printf( "%6.3f G bits/sec\n", rate);

	printf("SHA256 hash result:\t");
	for(k=0;k<32;++k)
	{
		printf("%.2x",(unsigned char)tmp[k]);
	}
	printf("\n");

	free(buffer);
	fclose(file);
	file=NULL;
	printf("\n\n");
	return 1;
}


